import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class deleteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/exam", "root", "");

            PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM emp WHERE id=?");

            ps.setString(1, id);
            ps.executeUpdate();

            con.close();

            response.sendRedirect("displayServlet");

        } catch (Exception e) {
            response.getWriter().println("Error: " + e);
        }
    }
}
