import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class insertServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String email = request.getParameter("email");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");   // Correct driver
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/exam", "root", "");

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO emp (name, age, email) VALUES (?, ?, ?)");

            ps.setString(1, name);
            ps.setString(2, age);
            ps.setString(3, email);
            ps.executeUpdate();

            con.close();

            // Redirect back to form
            response.sendRedirect("displayServlet");

        } catch (Exception e) {
            response.getWriter().println("Error: " + e);
        }
    }
}
