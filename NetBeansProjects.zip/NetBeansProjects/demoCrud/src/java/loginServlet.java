import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class loginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<h2>Use POST method to login.</h2>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String uname = request.getParameter("uname");
        String pass = request.getParameter("pass");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // javax uses old driver
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam", "root", "");

            PreparedStatement st = con.prepareStatement(
                "SELECT * FROM user WHERE uname=? AND pass=?"
            );
            st.setString(1, uname);
            st.setString(2, pass);

            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("uname", uname);

                response.sendRedirect("welcomeServlet"); 
            } else {
                out.println("<h3>Login Failed</h3>");
            }

            con.close();

        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
}


