import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class welcomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        // Do NOT create a new session here
        HttpSession session = request.getSession(false);

        // If no session or no username → redirect to login
        if (session == null || session.getAttribute("uname") == null) {
            response.sendRedirect("index.html");
            return;
        }

        PrintWriter out = response.getWriter();
        String uname = (String) session.getAttribute("uname");

        out.println("<!DOCTYPE html>");
        out.println("<html><body>");
        out.println("<a href='insert.html'>Insert record</a>");
        out.println("<h1>Welcome, " + uname + "</h1>");
        out.println("</body></html>");
        out.println("<a href='displayServlet'>Next</a>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
