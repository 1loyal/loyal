import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class displayServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/exam", "root", "");

            PreparedStatement ps = con.prepareStatement("SELECT * FROM emp");
            ResultSet rs = ps.executeQuery();

            out.println("<html><body>");
            out.println("<h2>Employee Records</h2>");
            out.println("<a href='insert.html'>Insert record</a><br><br>");

            out.println("<table border='1' cellpadding='10'>");
            out.println("<tr>"
                    + "<th>ID</th>"
                    + "<th>Name</th>"
                    + "<th>Age</th>"
                    + "<th>Email</th>"
                    + "<th>Update</th>"
                    + "<th>Delete</th>"
                    + "</tr>");

            while (rs.next()) {

                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String email = rs.getString("email");

                out.println("<tr>");
                out.println("<td>" + id + "</td>");
                out.println("<td>" + name + "</td>");
                out.println("<td>" + age + "</td>");
                out.println("<td>" + email + "</td>");

                // UPDATE BUTTON → update.html
                out.println("<td>"
                        + "<a href='update.html?id=" + id
                        + "&name=" + name
                        + "&age=" + age
                        + "&email=" + email + "'>"
                        + "<button>Update</button>"
                        + "</a>"
                        + "</td>");

                // DELETE BUTTON → deleteServlet
                out.println("<td>"
                        + "<a href='deleteServlet?id=" + id + "'>"
                        + "<button>Delete</button>"
                        + "</a>"
                        + "</td>");

                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

            con.close();

        } catch (Exception e) {
            out.println("Error: " + e);
        }
    }
}
