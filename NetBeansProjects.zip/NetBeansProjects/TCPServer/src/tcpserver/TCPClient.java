/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcpserver;

/**
 *
 * @author Hp
 */

import java.util.*;
import java.io.*;
import java.net.*;

public class TCPClient {
     public static void main(String[] args) throws Exception { 
        Socket s = new Socket("localhost", 5000); 
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
        PrintWriter pw = new PrintWriter(s.getOutputStream(), true); 
        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream())); 
        pw.println("Hello"); 
        System.out.println("Server: " + in.readLine()); 
        s.close(); 
    } 
}
