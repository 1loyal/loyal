/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcpserver;

/**
 *
 * @author Hp
 */

import java.util.*;
import java.io.*;
import java.net.*;

public class TCPServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception { 
        ServerSocket ss = new ServerSocket(5000); 
        System.out.println("Server started..."); 
        Socket s = ss.accept(); 
 
        BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream())); 
        PrintWriter pw = new PrintWriter(s.getOutputStream(), true); 
 
        String msg = br.readLine(); 
        System.out.println("Client: " + msg); 
        pw.println("Hi"); 
        s.close(); 
        ss.close(); 
    }
    
}
