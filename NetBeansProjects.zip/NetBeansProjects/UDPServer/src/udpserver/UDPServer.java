/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package udpserver;

/**
 *
 * @author Hp
 */

import java.util.*;
import java.io.*;
import java.net.*;

public class UDPServer {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) throws Exception { 
        DatagramSocket ds = new DatagramSocket(3000); 
        System.out.println("Server Connected");
        byte[] buf = new byte[1024]; 
        DatagramPacket dp = new DatagramPacket(buf, buf.length); 
        ds.receive(dp); 
 
        String msg = new String(dp.getData(), 0, dp.getLength()); 
        int n = Integer.parseInt(msg); 
        int fact = 1; 
        for (int i = 1; i <= n; i++) fact *= i; 
 
        String reply = String.valueOf(fact); 
        byte[] sendData = reply.getBytes(); 
        InetAddress ip = dp.getAddress(); 
        int port = dp.getPort(); 
        DatagramPacket dp1 = new DatagramPacket(sendData, sendData.length, ip, port); 
        ds.send(dp1); 
        ds.close(); 
    } 
    
}
