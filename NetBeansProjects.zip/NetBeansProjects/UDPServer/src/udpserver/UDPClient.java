/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package udpserver;

/**
 *
 * @author Hp
 */

import java.util.*;
import java.io.*;
import java.net.*;

public class UDPClient {
     public static void main(String[] args) throws Exception { 
        DatagramSocket ds = new DatagramSocket(); 
        Scanner sc = new Scanner(System.in); 
        System.out.print("Enter number: "); 
        String num = sc.nextLine(); 
 
        byte[] b = num.getBytes(); 
        InetAddress ip = InetAddress.getByName("localhost"); 
        DatagramPacket dp = new DatagramPacket(b, b.length, ip, 3000); 
        ds.send(dp); 
 
        byte[] buf = new byte[1024]; 
        DatagramPacket dp1 = new DatagramPacket(buf, buf.length); 
        ds.receive(dp1); 
        System.out.println("Factorial from server: " + new String(dp1.getData(), 0, dp1.getLength())); 
        ds.close(); 
    } 
}
