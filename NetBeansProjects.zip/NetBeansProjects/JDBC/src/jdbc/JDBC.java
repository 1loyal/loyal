/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

/**
 *
 * @author Hp
 */

import java.util.*;
import java.sql.*;

public class JDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { 
 
        String url = "jdbc:mysql://localhost:3306/employee"; 
        String user = "root"; 
        String password = ""; 
 
        Scanner sc = new Scanner(System.in); 
 
        try { 
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            Connection con = DriverManager.getConnection(url, user, password); 
            Statement st = con.createStatement(); 
            System.out.println("Connection done"); 
 
            int ch; 
 
            do { 
                System.out.println("\nMENU"); 
                System.out.println("1. Insert"); 
                System.out.println("2. Update"); 
                System.out.println("3. Delete"); 
                System.out.println("4. Show"); 
                System.out.println("5. Exit"); 
                System.out.print("Enter the choice: "); 
                ch = sc.nextInt(); 
                sc.nextLine(); 
 
                switch (ch) { 
 
                    case 1: 
                        System.out.print("Enter roll number: "); 
                        int rno = sc.nextInt(); 
                        sc.nextLine(); 
 
                        System.out.print("Enter name: "); 
                        String name = sc.nextLine(); 
 
                        System.out.print("Enter course: "); 
                        String course = sc.nextLine(); 
 
                        String insertQuery = "INSERT INTO student(rno, name, course) VALUES(" + rno + ",'" + name + "','" + course + "')"; 
                        int rowInserted = st.executeUpdate(insertQuery); 
 
                        if (rowInserted > 0) 
                            System.out.println("Inserted successfully"); 
                        break; 
 
                    case 2: 
                        System.out.print("Enter roll no to update: "); 
                        int urno = sc.nextInt(); 
                        sc.nextLine(); 
 
                        System.out.print("Enter new course: "); 
                        String newCourse = sc.nextLine(); 
 
                        String updateQuery = "UPDATE student SET course='" + newCourse + "' WHERE rno=" + urno; 
                        int rowUpdated = st.executeUpdate(updateQuery); 
 
                        if (rowUpdated > 0) 
                            System.out.println("Updated successfully"); 
                        break; 
 
                    case 3: 
                        System.out.print("Enter roll no to delete: "); 
                        int drno = sc.nextInt(); 
                        sc.nextLine(); 
 
                        String deleteQuery = "DELETE FROM student WHERE rno=" + drno; 
                        int rowDeleted = st.executeUpdate(deleteQuery); 
 
                        if (rowDeleted > 0) 
                            System.out.println("Deleted successfully"); 
                        break; 
 
                    case 4: 
                        ResultSet rs = st.executeQuery("SELECT * FROM student"); 
                        while (rs.next()) { 
                            System.out.println("Roll No: " + rs.getInt("rno")); 
                            System.out.println("Name: " + rs.getString("name")); 
                            System.out.println("Course: " + rs.getString("course")); 
                            System.out.println("-----------------------"); 
                        } 
                        break; 
 
                    case 5: 
                        System.out.println("Exiting..."); 
                        break; 
 
                    default: 
                        System.out.println("Invalid choice"); 
                } 
 
            } while (ch != 5); 
 
        } catch (Exception e) { 
            System.out.println(e); 
        } 
    } 
    
}
