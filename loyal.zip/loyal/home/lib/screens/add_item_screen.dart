import 'package:flutter/material.dart';
import '../models/item.dart';
import '../services/api_service.dart';

class AddItemScreen extends StatefulWidget {
  @override
  State<AddItemScreen> createState() => _AddItemScreenState();
}

class _AddItemScreenState extends State<AddItemScreen> {
  final ApiService api = ApiService();

  final TextEditingController userId = TextEditingController();
  final TextEditingController itemId = TextEditingController();
  final TextEditingController title = TextEditingController();
  final TextEditingController body = TextEditingController();

  void submitForm() async {
    final item = Item(
      userId: int.tryParse(userId.text),
      id: int.tryParse(itemId.text),
      title: title.text,
      body: body.text,
    );

    await api.createItem(item);

    Navigator.pop(context);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Item Added")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Item")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: userId,
              decoration: InputDecoration(labelText: "User ID"),
            ),
            TextField(
              controller: itemId,
              decoration: InputDecoration(labelText: "ID"),
            ),
            TextField(
              controller: title,
              decoration: InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: body,
              decoration: InputDecoration(labelText: "Description"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: submitForm,
              child: Text("Add Item"),
            ),
          ],
        ),
      ),
    );
  }
}
