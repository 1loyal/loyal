import 'package:flutter/material.dart';
import '../models/item.dart';
import '../services/api_service.dart';

class EditItemScreen extends StatefulWidget {
  final Item item;

  EditItemScreen({required this.item});

  @override
  State<EditItemScreen> createState() => _EditItemScreenState();
}

class _EditItemScreenState extends State<EditItemScreen> {
  final ApiService api = ApiService();

  late TextEditingController name;
  late TextEditingController description;

  @override
  void initState() {
    super.initState();
    name = TextEditingController(text: widget.item.title);
    description = TextEditingController(text: widget.item.body);
  }

  void updateItem() async {
    final updatedItem = Item(
      id: widget.item.id,
      userId: widget.item.userId,
      title: name.text,
      body: description.text,
    );

    await api.updateItem(widget.item.id!, updatedItem);

    Navigator.pop(context);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Item Updated")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Edit Item")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: name,
              decoration: InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: description,
              decoration: InputDecoration(labelText: "Description"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: updateItem,
              child: Text("Update Item"),
            ),
          ],
        ),
      ),
    );
  }
}
