import 'package:flutter/material.dart';
import '../models/item.dart';
import '../services/api_service.dart';

class DeleteItemScreen extends StatelessWidget {
  final Item item;
  final ApiService api = ApiService();

  DeleteItemScreen({required this.item});

  void deleteItem(BuildContext context) async {
    await api.deleteItem(item.id!);

    Navigator.pop(context);     // Close screen
    Navigator.pop(context);     // Return to list

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Item Deleted")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Delete Item")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Delete this item?",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text("Name: ${item.title}"),
            Text("Description: ${item.body}"),
            SizedBox(height: 40),
            Row(
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text("Cancel"),
                ),
                SizedBox(width: 20),
                ElevatedButton(
                  onPressed: () => deleteItem(context),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: Text("Delete"),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
