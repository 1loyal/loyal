import 'package:flutter/material.dart';
import '../models/item.dart';
import '../services/api_service.dart';
import 'add_item_screen.dart';
import 'edit_item_screen.dart';

class ItemListScreen extends StatefulWidget {
  @override
  State<ItemListScreen> createState() => _ItemListScreenState();
}

class _ItemListScreenState extends State<ItemListScreen> {
  final ApiService api = ApiService();

  List<Item> items = [];

  @override
  void initState() {
    super.initState();
    loadItems();
  }

  void loadItems() async {
    final data = await api.fetchItems();
    setState(() => items = data);
  }

  void deleteItem(int id) async {
    await api.deleteItem(id);
    loadItems();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Item Deleted")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Items"),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AddItemScreen()),
              );
              loadItems();
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Item>>(
          future: api.fetchItems(),
          builder: (context,snap){
            if(!snap.hasData) return Center(child: CircularProgressIndicator());
            final items = snap.data!;

            if(items.isEmpty) return Center(child: Text("no item"));

            return ListView.builder(
                itemCount: items.length,
                itemBuilder: (_, i){
                  final item = items[i];
                  return ListTile(
                    title: Text(item.title ?? ""),
                    subtitle: Text(item.body ?? ""),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Edit button
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => EditItemScreen(item: item),
                              ),
                            );
                            loadItems();
                          },
                        ),

                        // Delete button
                        IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () => deleteItem(item.id!),
                        ),
                      ],
                    ),
                  );
                }
            );
          }

      ),
    );
  }
}
